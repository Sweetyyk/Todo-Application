package com.example.todoapplication.todoapp.service;

import org.springframework.stereotype.Service;

@Service
public interface Authenticate
{
public boolean check(String name, String password);

}
